"use client"

import { motion } from "framer-motion"
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ComposedChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from "recharts"
import { ReferenceDot } from "recharts"
import {
  useDashboardKPIs,
  useEnergyTrend,
  useCarbonBreakdown,
} from "@/hooks/use-dashboard-data"

import { EmptyState } from "@/components/dashboard/empty-state"
import { TopDevicesCard } from "@/components/dashboard/top-devices-card"

export function EnergyTab({ filters }: { filters: any }) {
  const { data: kpis, isLoading, error } =
    useDashboardKPIs({ range: filters.timeRange })

  const { data: trendData = [] } =
    useEnergyTrend({ range: filters.timeRange })

  const { data: carbonResponse } = useCarbonBreakdown()

  const carbonBreakdown = Array.isArray(carbonResponse)
    ? carbonResponse
    : (carbonResponse as any)?.data ?? []

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="h-96 bg-muted rounded animate-pulse" />
      </div>
    )
  }

  if (error) return <EmptyState type="api-error" />
  if (!kpis) return <EmptyState type="no-data" />

  /* =========================
     KPI VALUES
  ========================= */

  const totalCost = kpis.totalCost ?? 0
  const totalEnergy =
    kpis.totalEnergyConsumption?.value ?? 0

  const avgLoad =
    trendData.length > 0
      ? (
          trendData.reduce(
            (sum: number, d: any) =>
              sum + Number(d.total_kwh ?? 0),
            0
          ) / trendData.length
        ).toFixed(2)
      : "0"

  const peakLoad =
    trendData.length > 0
      ? Math.max(
          ...trendData.map(
            (d: any) => Number(d.peak_power ?? 0)
          )
        )
      : 0

  /* =========================
     DAILY DATA
  ========================= */

  const safeTrendData = Array.isArray(trendData)
    ? trendData
    : []

  const consumptionData = safeTrendData.map(
    (item: any) => ({
      date: new Date(item.timestamp).toLocaleDateString(
        "en-US",
        { month: "short", day: "numeric" }
      ),
      total: Number(item.total_kwh ?? 0),
      baseline: Number(item.baseline_kwh ?? 0),
    })
  )

  const isShortRange =
    filters.timeRange === "7d" ||
    filters.timeRange === "24h"

  /* =========================
     ENERGY MIX
  ========================= */

  const totalCarbon = carbonBreakdown.reduce(
    (sum: number, item: any) =>
      sum + Number(item.value ?? 0),
    0
  )

  const consumptionMix = carbonBreakdown.map(
    (item: any, index: number) => ({
      name: item.source,
      value:
        totalCarbon > 0
          ? Math.round(
              (Number(item.value ?? 0) /
                totalCarbon) *
                100
            )
          : 0,
      color: [
        "#3B82F6",
        "#10B981",
        "#F59E0B",
        "#EF4444",
        "#8B5CF6",
      ][index % 5],
    })
  )
    const peakPoint =
    consumptionData.length > 0
      ? consumptionData.reduce((max, d) =>
          d.total > max.total ? d : max
        )
      : null
  
      const topDevices = [
      { name: "Oven", power: 3830 },
      { name: "Gas Furnace", power: 380 },
      { name: "Guest Bedroom", power: 269 },
      { name: "Office", power: 231 },
      { name: "Living Room", power: 176 },
    ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* TOP GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

          {/* COST CARD */}
          <div className="bg-slate-800/50 rounded-2xl p-8 border border-slate-700/30 shadow-lg">
            <p className="text-slate-400 text-sm mb-2">
              Total Cost
            </p>
            <div className="text-4xl font-bold tracking-tight">
              £{totalCost.toFixed(2)}
            </div>

            <div className="mt-6 pt-6 border-t border-slate-700/30">
              <p className="text-slate-400 text-sm">
                Total Energy Usage
              </p>
              <p className="text-2xl font-semibold">
                {totalEnergy.toLocaleString()} kWh
              </p>
            </div>

            <div className="mt-4 text-sm text-slate-400">
              Avg Load: {avgLoad} | Peak Load:{" "}
              {peakLoad}
            </div>
          </div>

          {/* ENERGY MIX */}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/30 shadow-lg">
            <h3 className="text-sm font-semibold mb-4">
              Energy Consumption Mix
            </h3>

            {consumptionMix.length === 0 ? (
              <EmptyState type="no-data" />
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={consumptionMix}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={3}
                  >
                    {consumptionMix.map(
                      (entry: { name: string; value: number; color: string }, index: number) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                        />
                      )
                    )}
                  </Pie>

                  <Tooltip
                    formatter={(v: any, n: any) => [
                      `${v}%`,
                      n,
                    ]}
                    contentStyle={{
                      backgroundColor: "#0F172A",
                      border: "1px solid #334155",
                      borderRadius: "8px",
                    }}
                  />

                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    wrapperStyle={{
                      color: "#CBD5E1",
                      fontSize: "12px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
        
        <TopDevicesCard devices={topDevices} />

        {/* DAILY BREAKDOWN CARD */}
        <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/30 shadow-lg">
          <h3 className="text-sm font-semibold mb-4">
            Daily Breakdown
          </h3>

          {consumptionData.length === 0 ? (
            <EmptyState type="no-data" />
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              {isShortRange ? (
                <ComposedChart data={consumptionData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#334155"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#94A3B8", fontSize: 12 }}
                  />
                  <YAxis
                    tick={{ fill: "#94A3B8", fontSize: 12 }}
                  />
                  <Tooltip />
                  <Legend />

                  <Bar
                    dataKey="total"
                    name="Energy (kWh)"
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                  />
                  <Bar
                    dataKey="baseline"
                    name="Baseline"
                    fill="#F59E0B"
                    radius={[4, 4, 0, 0]}
                  />
                </ComposedChart>
              ) : (
                <LineChart data={consumptionData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#334155"
                    vertical={false}
                  />

                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#94A3B8", fontSize: 12 }}
                    tickLine={false}
                    axisLine={{ stroke: "#334155" }}
                  />

                  <YAxis
                    tick={{ fill: "#94A3B8", fontSize: 12 }}
                    tickLine={false}
                    axisLine={{ stroke: "#334155" }}
                  />

                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0F172A",
                      border: "1px solid #334155",
                      borderRadius: "12px",
                      color: "white",
                    }}
                    labelStyle={{ color: "#94A3B8" }}
                    formatter={(value: any, name: any) => [
                      `${value.toLocaleString()} kWh`,
                      name,
                    ]}
                  />

                  <Legend
                    wrapperStyle={{
                      color: "#CBD5E1",
                      fontSize: "12px",
                    }}
                  />

                  {/* ENERGY LINE */}
                  <Line
                    type="monotone"
                    dataKey="total"
                    stroke="#3B82F6"
                    strokeWidth={3}
                    dot={false}
                    activeDot={{
                      r: 6,
                      stroke: "#fff",
                      strokeWidth: 2,
                    }}
                    name="Energy (kWh)"
                  />

                  {/* BASELINE */}
                  <Line
                    type="monotone"
                    dataKey="baseline"
                    stroke="#F59E0B"
                    strokeWidth={2}
                    dot={false}
                    strokeDasharray="5 5"
                    activeDot={{
                      r: 5,
                    }}
                    name="Baseline"
                  />

                  {/* PEAK POINT */}
                  {peakPoint && (
                    <ReferenceDot
                      x={peakPoint.date}
                      y={peakPoint.total}
                      r={7}
                      fill="#EF4444"
                      stroke="white"
                      strokeWidth={2}
                    />
                  )}
                </LineChart>
              )}
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  )
}