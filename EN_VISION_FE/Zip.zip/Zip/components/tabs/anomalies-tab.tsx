"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  AlertTriangle,
  AlertCircle,
  Info,
  XCircle,
  ChevronDown,
  Clock,
  Zap,
  Building2,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useAnomalies } from "@/hooks/use-dashboard-data"
import { WhyTooltip } from "@/components/dashboard/why-tooltip"
import { EmptyState } from "@/components/dashboard/empty-state"

import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts"

import type { AnomalyPoint } from "@/lib/api/dashboard"

const severityConfig = {
  low: {
    icon: Info,
    color: "text-chart-1",
    bg: "bg-chart-1/10",
    fill: "oklch(0.75 0.15 195)",
  },
  medium: {
    icon: AlertCircle,
    color: "text-chart-3",
    bg: "bg-chart-3/10",
    fill: "oklch(0.75 0.15 85)",
  },
  high: {
    icon: AlertTriangle,
    color: "text-chart-4",
    bg: "bg-chart-4/10",
    fill: "oklch(0.65 0.2 25)",
  },
  critical: {
    icon: XCircle,
    color: "text-destructive",
    bg: "bg-destructive/10",
    fill: "oklch(0.55 0.25 25)",
  },
}

const impactConfig = {
  low: { label: "Low Impact", className: "text-chart-1 bg-chart-1/10" },
  medium: { label: "Medium Impact", className: "text-chart-3 bg-chart-3/10" },
  high: { label: "High Impact", className: "text-chart-4 bg-chart-4/10" },
}

const getSeverityKey = (severity?: string) =>
  (severity?.toLowerCase() as keyof typeof severityConfig) || "low"

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null
  const data = payload[0].payload
  const key = getSeverityKey(data.severity)
  return (
    <div className="glass-card p-3 border border-border">
      <p className="text-xs mb-1">
        {new Date(data.timestamp).toLocaleString()}
      </p>
      <p className="text-sm font-medium">{data.description}</p>
      <p className="text-xs mt-1">
        Value: <span>{data.value?.toLocaleString?.() ?? 0}</span>
      </p>
      <p className="text-xs capitalize">
        Severity:{" "}
        <span className={severityConfig[key]?.color}>
          {data.severity ?? "low"}
        </span>
      </p>
    </div>
  )
}

function MiniTimeSeriesChart({ baseValue }: { baseValue: number }) {
  const data = Array.from({ length: 12 }, (_, i) => ({
    time: `${i}:00`,
    value: baseValue * (0.85 + Math.random() * 0.3),
    baseline: baseValue,
  }))

  return (
    <div className="h-24">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="time" hide />
          <YAxis hide />
          <Line type="monotone" dataKey="baseline" strokeDasharray="4 4" dot={false} />
          <Line type="monotone" dataKey="value" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

function AnomalyItem({ anomaly, index }: { anomaly: any; index: number }) {
  const [isExpanded, setIsExpanded] = useState(false)

  const key = getSeverityKey(anomaly.severity)
  const config = severityConfig[key]
  const impact =
    impactConfig[anomaly.impact?.toLowerCase() as keyof typeof impactConfig] ??
    impactConfig.low

  const Icon = config.icon

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-lg bg-secondary/50 overflow-hidden"
    >
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center gap-4 p-3"
      >
        <div className={cn("p-2 rounded-lg", config.bg)}>
          <Icon className={cn("w-4 h-4", config.color)} />
        </div>

        <div className="flex-1 text-left">
          <p className="text-sm">{anomaly.description}</p>
          <p className="text-xs">
            {new Date(anomaly.timestamp).toLocaleString()} •{" "}
            {anomaly.value?.toLocaleString?.() ?? 0}
          </p>
        </div>

        <span className={cn("text-xs px-2 py-1 rounded", impact.className)}>
          {impact.label}
        </span>

        <span
          className={cn(
            "text-xs capitalize px-2 py-1 rounded",
            config.bg,
            config.color
          )}
        >
          {anomaly.severity}
        </span>

        <ChevronDown
          className={cn("w-4 h-4 transition-transform", isExpanded && "rotate-180")}
        />
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t"
          >
            <div className="p-4 space-y-4">
              <MiniTimeSeriesChart baseValue={(anomaly.value ?? 0) / 10} />
              <p className="text-xs">{anomaly.explanation}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export function AnomaliesTab() {
  const { data: anomalies, isLoading, error, refetch } = useAnomalies()

  if (isLoading) return <div className="p-6 h-64 bg-muted animate-pulse" />
  if (error)
    return (
      <div className="p-6">
        <EmptyState type="api-error" onRetry={() => refetch()} />
      </div>
    )
  if (!anomalies || anomalies.length === 0)
    return <EmptyState type="no-anomalies" />

  const chartData = anomalies.map((a: any, i: number) => ({
    ...a,
    index: i,
    hour: new Date(a.timestamp).getHours(),
  }))

  return (
    <div className="p-6 space-y-6">
      <div className="glass-card p-5">
        <ResponsiveContainer width="100%" height={300}>
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" dataKey="hour" domain={[0, 24]} />
            <YAxis type="number" dataKey="value" />
            <Tooltip content={<CustomTooltip />} />
            <Scatter data={chartData}>
              {chartData.map((entry: any, index: number) => (
                <Cell
                  key={index}
                  fill={
                    severityConfig[getSeverityKey(entry.severity)]?.fill ??
                    "#6B7280"
                  }
                />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>

      <div className="glass-card p-5 space-y-3">
        {anomalies.slice(0, 5).map((anomaly: any, index: number) => (
          <AnomalyItem
            key={anomaly.id ?? `${anomaly.timestamp ?? "no-ts"}-${index}`}
            anomaly={anomaly}
            index={index}
          />
        ))}
      </div>
    </div>
  )
}
