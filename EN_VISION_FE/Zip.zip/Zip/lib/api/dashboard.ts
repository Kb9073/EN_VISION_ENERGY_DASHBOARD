import apiClient_ from "@/lib/api/client"
import { DashboardKPIs, StandardResponse } from "@/types/dashboard"

/* =========================
   TYPES
========================= */

export interface EnergyTrendPoint {
  timestamp: string
  total_kwh: number
  total_cost: number
  total_emissions: number
  peak_power: number
  baseline_kwh: number
}

export interface DeviationOverTimePoint {
  date: string
  deviation: number
}

export interface CostMetrics {
  total_cost: number
  electricity_cost: number
  gas_cost: number
  previous_cost: number
  current_cost: number
  previous_month: string
  current_month: string
  cost_change_percent: number
}

export interface EnergyIntensity {
  intensity: number
  current_usage: number
  predicted_usage: number
  usage_history: Array<{ date: string; value: number }>
  carbon_till_date: number
  carbon_predicted: number
  green_energy_percent: number
}

export interface ActiveAppliance {
  name: string
  usage: number
  maxUsage?: number
}

export interface DeviationData {
  zone: string
  actual: number
  baseline: number
  deviation: number
  deviationPercent: number
}

export interface AnomalyPoint {
  id: string
  timestamp: string
  severity: string
  description: string
}

export interface ForecastPoint {
  forecast_date: string
  predicted_kwh: number
  actual_kwh?: number | null
  is_forecast: boolean
}

export interface CarbonMetrics {
  totalEmissions: number
  delta: number
}

export interface CarbonBreakdown {
  source: string
  value: number
}

export interface AIInsight {
  title: string
  description: string
  severity: "low" | "medium" | "high"
  timestamp: string
}

export interface Recommendation {
  title: string
  description: string
  severity: "low" | "medium" | "high"
}

/* =========================
   HELPER
========================= */

const unwrap = async <T>(
  promise: Promise<StandardResponse<T>>
): Promise<T> => {
  try {
    const response = await promise

    if (!response || response.data === undefined || response.data === null) {
      return (Array.isArray(response?.data) ? ([] as unknown as T) : ({} as T))
    }

    return response.data
  } catch {
    return ([] as unknown) as T
  }
}

/* =========================
   API FUNCTIONS
========================= */

export const getKPIs = async (
  params?: any
): Promise<DashboardKPIs> => {
  try {
    return await unwrap(
      apiClient_.get<StandardResponse<DashboardKPIs>>(
        "/dashboard/kpis",
        params,
        { showErrors: true }
      )
    )
  } catch (error) {
    console.error("[Dashboard] Failed to fetch KPIs:", error)
    return {
      totalEnergyConsumption: { value: 0, delta: 0 },
      energySaved: { value: 0, delta: 0 },
      overConsumptionPercent: { value: 0, delta: 0 },
      co2Emissions: { value: 0, delta: 0 },
      avgConsumption: 0,
      peakConsumption: 0,
      totalCost: 0,
      systemStatus: "stable",
      sustainabilityStatus: "on-track",
    }
  }
}

export const getEnergyTrend = async (
  params?: any
): Promise<EnergyTrendPoint[]> => {
  try {
    const data = await unwrap(
      apiClient_.get<StandardResponse<any[]>>(
        "/dashboard/energy-trend",
        params,
        { showErrors: true }
      )
    )

    if (!Array.isArray(data)) return []

    return data.map((item) => ({
      timestamp: item.timestamp,
      total_kwh: item.total_kwh,
      total_cost: item.total_cost,
      total_emissions: item.total_emissions,
      peak_power: item.peak_power,
      baseline_kwh: item.baseline_kwh,
    }))
  } catch (error) {
    console.error("[Dashboard] Failed to fetch energy trend:", error)
    return []
  }
}

export const getDeviationOverTime = async (
  params?: any
): Promise<DeviationOverTimePoint[]> =>
  unwrap(
    apiClient_.get<StandardResponse<DeviationOverTimePoint[]>>(
      "/dashboard/deviation-over-time",
      params,
      { showErrors: true }
    )
  )

export const getCostMetrics = async (
  params?: any
): Promise<CostMetrics> =>
  unwrap(
    apiClient_.get<StandardResponse<CostMetrics>>(
      "/dashboard/cost-metrics",
      params,
      { showErrors: true }
    )
  )

export const getEnergyIntensity = async (
  params?: any
): Promise<EnergyIntensity> =>
  unwrap(
    apiClient_.get<StandardResponse<EnergyIntensity>>(
      "/dashboard/energy-intensity",
      params,
      { showErrors: true }
    )
  )

export const getActiveAppliances = async (
  params?: any
): Promise<ActiveAppliance[]> =>
  unwrap(
    apiClient_.get<StandardResponse<ActiveAppliance[]>>(
      "/dashboard/active-appliances",
      params,
      { showErrors: true }
    )
  )

export const getDeviations = async (
  params?: any
): Promise<DeviationData[]> =>
  unwrap(
    apiClient_.get<StandardResponse<DeviationData[]>>(
      "/dashboard/deviations",
      params,
      { showErrors: true }
    )
  )

export const getAnomalies = async (
  params?: any
): Promise<AnomalyPoint[]> =>
  unwrap(
    apiClient_.get<StandardResponse<AnomalyPoint[]>>(
      "/dashboard/anomalies",
      params,
      { showErrors: true }
    )
  )

export const getForecast = async (
  params?: any
): Promise<ForecastPoint[]> => {
  try {
    const response = await apiClient_.get<
      StandardResponse<ForecastPoint[]>
    >("/dashboard/forecast", params, { showErrors: true })

    if (!response || !Array.isArray(response.data)) {
      return []
    }

    return response.data
  } catch (error) {
    console.error("[Forecast Error]", error)
    return []
  }
}

export const getCarbonMetrics = async (
  params?: any
): Promise<CarbonMetrics> =>
  unwrap(
    apiClient_.get<StandardResponse<CarbonMetrics>>(
      "/dashboard/carbon-metrics",
      params,
      { showErrors: true }
    )
  )

export const getCarbonBreakdown = async (
  params?: any
): Promise<CarbonBreakdown[]> => {
  return unwrap(
    apiClient_.get<StandardResponse<CarbonBreakdown[]>>(
      "/dashboard/carbon-breakdown",
      params,
      { showErrors: true }
    )
  )
}

export const getAIInsights = async (
  params?: any
): Promise<AIInsight[]> => {
  try {
    const data = await unwrap(
      apiClient_.get<StandardResponse<AIInsight[]>>(
        "/dashboard/ai-insights",
        params,
        { showErrors: true }
      )
    )

    return Array.isArray(data) ? data : []
  } catch {
    return []
  }
}

export const getRecommendations = async (
  params?: any
): Promise<Recommendation[]> => {
  try {
    const data = await unwrap(
      apiClient_.get<StandardResponse<Recommendation[]>>(
        "/dashboard/recommendations",
        params,
        { showErrors: true }
      )
    )
    return Array.isArray(data) ? data : []
  } catch {
    return []
  }
}