import axios from "axios"

const apiClient_ = axios.create({
  baseURL: "http://localhost:8000", // ✅ IMPORTANT
  headers: {
    "Content-Type": "application/json",
  },
})

const client = {
  get: async <T>(
    url: string,
    params?: any,
    options?: { showErrors?: boolean }
  ): Promise<T> => {
    try {
      const response = await apiClient_.get<T>(url, { params })
      return response.data
    } catch (error: any) {
      console.error("[API ERROR]", error?.response?.data || error.message)
      throw error
    }
  },
}

export default client 