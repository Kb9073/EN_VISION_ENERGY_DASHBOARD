import axios, { AxiosRequestConfig } from "axios"

const apiClient_ = {
  get: async <T>(
    url: string,
    params?: any,
    config?: { showErrors?: boolean }
  ): Promise<T> => {
    try {
      const response = await axios.get<T>(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}${url}`,
        {
          params,
        }
      )

      return response.data
    } catch (error: any) {
      if (config?.showErrors) {
        console.error("[API GET ERROR]", error?.response?.data || error.message)
      }
      throw error
    }
  },
}

export default apiClient_